-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2022 at 05:28 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `librarymanage`
--

-- --------------------------------------------------------

--
-- Table structure for table `accountpage`
--

CREATE TABLE `accountpage` (
  `Username` varchar(100) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accountpage`
--

INSERT INTO `accountpage` (`Username`, `fullname`, `mobile`, `gender`, `password`) VALUES
('vikasagg', 'vikas aggarwal', '1234567890', 'male', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `bookpage`
--

CREATE TABLE `bookpage` (
  `bookid` varchar(100) NOT NULL,
  `bookname` varchar(100) NOT NULL,
  `pubname` varchar(100) NOT NULL,
  `bookprice` int(100) NOT NULL,
  `pubdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookpage`
--

INSERT INTO `bookpage` (`bookid`, `bookname`, `pubname`, `bookprice`, `pubdate`) VALUES
('1', 'core java', 'arjun sharma', 5000, '2022-09-09'),
('2', 'core java', 'rk singh', 1000, '2022-09-08'),
('3', 'python full', 'rk singla', 200, '2012-09-20'),
('4', 'python advance', 'karan bhardwaj', 3000, '2022-09-09');

-- --------------------------------------------------------

--
-- Table structure for table `issuepage`
--

CREATE TABLE `issuepage` (
  `bookid` varchar(100) NOT NULL,
  `studentid` varchar(100) NOT NULL,
  `issuedate` date NOT NULL,
  `duedate` date NOT NULL,
  `returnbook` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issuepage`
--

INSERT INTO `issuepage` (`bookid`, `studentid`, `issuedate`, `duedate`, `returnbook`) VALUES
('1', '3920', '2022-09-03', '2022-09-23', 'yes'),
('1', '3920', '2022-09-01', '2022-09-15', '0'),
('3', '22/20', '2022-09-01', '2022-09-14', 'yes'),
('4', '22/20', '2022-09-08', '2022-09-30', '0');

-- --------------------------------------------------------

--
-- Table structure for table `studentpage`
--

CREATE TABLE `studentpage` (
  `studentid` varchar(100) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `mobile` int(100) NOT NULL,
  `rollno` int(100) NOT NULL,
  `course` varchar(100) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentpage`
--

INSERT INTO `studentpage` (`studentid`, `fullname`, `mobile`, `rollno`, `course`, `branch`, `gender`, `address`) VALUES
('22/20', 'varun kumar', 1234567890, 2003740, 'Btech', 'ece', 'male', 'delhi,delhi'),
('3920', 'uday kapoor', 1234567890, 2003777, 'Btech', 'IT', 'male', 'shastri nagar,jalandhar'),
('vikas1', 'vikas aggarwal', 1234567890, 39, 'Btech', 'cse', 'male', 'shahkot,jalandhar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accountpage`
--
ALTER TABLE `accountpage`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `bookpage`
--
ALTER TABLE `bookpage`
  ADD PRIMARY KEY (`bookid`);

--
-- Indexes for table `studentpage`
--
ALTER TABLE `studentpage`
  ADD PRIMARY KEY (`studentid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
