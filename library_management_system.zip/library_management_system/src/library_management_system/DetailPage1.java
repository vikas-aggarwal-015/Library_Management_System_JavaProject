package library_management_system;
public interface DetailPage1
{
    String path = "jdbc:mysql://localhost/librarymanage";
    String username ="root";
    String password="";
}
