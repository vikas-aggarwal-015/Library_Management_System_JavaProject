package library_management_system;
        
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import static library_management_system.DetailPage1.password;
import static library_management_system.DetailPage1.path;
import static library_management_system.DetailPage1.username;
public class Library_management_system
{
        public static void main(String[] args) 
        {
            try {
                    for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                        if ("Windows".equals(info.getName())) 
                        {
                            javax.swing.UIManager.setLookAndFeel(info.getClassName());
                            break;
                        }
                    }
                } 
                catch (Exception ex) 
                {
                    java.util.logging.Logger.getLogger(homepage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }

                try
                {
                    Connection conn = DriverManager.getConnection(path, username, password);
                    String myqry = "select * from accountpage";
                    PreparedStatement st = conn.prepareStatement(myqry);  
                    ResultSet rst = st.executeQuery(); 
                    if(rst.next())
                    { 
                        homepage obj = new homepage();
                        obj.setVisible(true);

                    }
                    else
                    {
                        internalhomepage obj = new internalhomepage();
                        obj.setVisible(true);
                    }  
                } 
                catch (Exception ex)
                {

                } 
        } 
    }
